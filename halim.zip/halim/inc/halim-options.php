<?php
if(class_exists('CSF')){
    
    $prefix= 'halim_options';

    CSF::createOptions($prefix,array(
        'menu_title'=>__('Halim Options','halim'),
        'menu_slug'=> 'halim-options',
        'framework_title'=> 'Halim Options',
        'menu_parent'=> 'themes.php',
        'menu_type'=>'submenu'
    ));

    // Header Options
    CSF::createSection($prefix,array(
        'id'=> 'header_options',
        'title'=> __('Header Options','halim'),
        'icon'=> 'fas fa-address-card',
        
    ));
    CSF::createSection($prefix,array(
        'parent'=> 'header_options',
        'title' => __('Header Left','halim'),
        'fields'=> array(
            array(
                'id'=> 'header_email',
                'type'=> 'text',
                'title'=> __('Email Address','halim'),
                ),
                array(
                    'id'=> 'header_phone',
                    'type'=> 'text',
                    'title'=> __('Phone Number','halim'),
                    )
        )
    ));
    CSF::createSection($prefix,array( 
        'title' => 'Header icons',
        'parent' => 'header_options',
        'fields' => array(
            array(
                'id' => 'header_icons',
                'type' => 'group',
                'button_title' => 'Add new Social Box',
                'title' => __('Header Icons','halim'  ) ,           
                'fields' =>array(
                    array(
                        'id' => 'social_title',
                        'type' =>'text',
                        'title' => __('Social Title','halim'),
                    ),
                    array(
                        'id' => 'social_link',
                        'type' =>'text',
                        'title' => __('Social Link','halim'),
                    ),
                    array(
                        'id' => 'social_icon',
                        'type' => 'icon',
                        'title' => __('Social icon','halim'),
                    )
                )
            )
        )
    ));
    CSF::createSection($prefix,array(
              'parent'  => 'header_options',
              'title' => __('Logo','halim'),
               'fields'=> array(
            array(
                'id' => 'logo',
                'type'=> 'media',
                'title'=> __('Upload Logo','halim'),
            )
        )
    ));
    // About Options
        CSF::createSection($prefix,array(
            'id'=> 'about_options',
            'title'=> __('About Section','halim'),
            'icon'=> 'fas fa-arrow-right',
        ));
        // About Section Title
        CSF::createSection($prefix,array(
            'parent' => 'about_options',
            'title'=>__('About Section Title','halim'),
            'icon'=>'fas fa-arrow-right',
            'fields'=> array(
                array(
                    'id'=> 'about_sec_subtitle',
                    'title'=> __('Sub title','halim'),
                    'type'=> 'text',
                    'desc' =>__('Write Subtitle Here','halim'),
                    
                ),
                array(
                    'id'=> 'about_sec_title',
                    'title'=> __('Title','halim'),
                    'type'=> 'text',                    
                ),
                array(
                    'id'=> 'about_sec_titles',
                    'title'=> __('Description','halim'),
                    'type'=> 'textarea',                    
                ),
            )

        ));
        // About Page Content

        CSF::createSection($prefix,array(
            'parent' => 'about_options',
            'title'=>__('About Page Content','halim'),
            'icon'=>'fas fa-arrow-right',
            'fields'=> array(
                array(
                    'id'=> 'about_page_title',
                    'title'=> __('title','halim'),
                    'type'=> 'text',
                    'desc' =>__('Write about page title here','halim'),
                    
                ),
                array(
                    'id'=> 'about_page_desc',
                    'title'=> __('About Page Description','halim'),
                    'type'=> 'textarea',                    
                ),
                array(
                    'id'=> 'about_page_button',
                    'title'=> __('About Page Link','halim'),
                    'type'=> 'text',                    
                ),
            )

        ));
        // About Page features

        CSF::createSection($prefix,array(
            'parent' => 'about_options',
            'title'=>__('About Page Fetures','halim'),
            'icon'=>'fas fa-arrow-right',
            'fields'=> array(
                array(
                    'id'=> 'about_page_features',
                    'title'=> __('About Feature','halim'),
                    'type'=> 'group',
                    'button_title'=> __('Add New Feature','halim'),
                    'desc' =>__('Write about page title here','halim'),
                    'fields'=> array(
                        array(
                            'id'=>'Fetures_title',
                            'title'=> __('About feature Title','halim'),
                            'type'=> 'text'
                        ),
                        array(
                            'id'=>'Fetures_icon',
                            'title'=> __('About feature Icon','halim'),
                            'type'=> 'icon'
                        ),
                        array(
                            'id'=>'Fetures_desc',
                            'title'=> __('About feature Description','halim'),
                            'type'=> 'textarea'
                        ),
                    )
                    
                ),
               
            )

        ));
        CSF::createSection($prefix,array(
            'parent' => 'about_options',
            'title' => __('About Info','halim'),
            'fields'=> array(
                array(
                    'id'=>'about_faq_list',
                    'title'=> __('About Faq','halim'),
                    'type'=> 'group',
                    'button_title'=> __('Add New Faq','halim'),
                    'fields'=> array(
                        array(
                            'id'=>'faq_title',
                            'title'=>__('Faq Title','halim'),
                            'type'=> 'text',
                         ),
                            array(
                                'id'=>'faq_des',
                                'title'=>__('Faq Description','halim'),
                                'type'=> 'textarea'
                            )

                        )
                )
            )
         ));
         CSF::createSection($prefix,array(
            'parent' => 'about_options',
            'title' => __('About Skills','halim'),
            'fields'=> array(
                array(
                    'id'=>'about_skill_list',
                    'title'=> __('About Skill','halim'),
                    'type'=> 'group',
                    'button_title'=> __('Add New Skill','halim'),
                    'fields'=> array(
                        array(
                            'id'=>'skill_title',
                            'title'=>__('Skill Title','halim'),
                            'type'=> 'text',
                         ),
                            array(
                                'id'=>'skill_number',
                                'title'=>__('skill Number','halim'),
                                'type'=> 'text'
                            )

                        )
                )
            )
         ));
         // Counter section
         CSF::createSection($prefix,array(
             'id'=> 'counter_options',
             'title'=> __('Counter Options' ,'halim'),
             'icon'=> 'fas fa-rocket',
             'fields'=> array(
                 array(
                     'id' => 'counter_lists',
                     'title'=>__('Counter List','halim'),
                     'type' => 'group',
                     'button_title'=> __('Add New Counter','halim'),
                     'fields'=> array(
                        array(
                            'id'=> 'counter_title',
                            'type' => 'text',
                            'title'=> __('Counter Title','halim')

                        ),
                        array(
                            'id'=> 'counter_number',
                            'type' => 'number',
                            'title'=> __('Counter Number','halim')

                        ),
                         array(
                             'id'=> 'counter_icon',
                             'type' => 'icon',
                             'title'=> __('Counter Icon','halim')

                         )
                     
                       
                     )

                 )
             )
         ));
         //CTA Option
         CSF::createSection($prefix,array(
             'id'=> 'cta_options',
             'title'=> __('CTA Options','halim'),
             'icon'=> 'fas fa-bullhorn',
             'fields'=> array(
                 array(
                     'id'=> 'cta_swtich',
                     'type'=> 'switcher',
                     'title'=> __('Show CTA?','halim'),
                     'default'=> true
                 ),
                 array(
                     'id'=> 'cta_title',
                     'type'=> 'text',
                     'title'=> __('CTA Title','halim'),
                     'default'=> __('Best Solution For Your Business','halim'),
                     'help'=> __('CTA Text Write Here.','halim'),
                     'dependency'=> array('cta_swtich','==','true')
                     
                 ),
                 array(
                    'id'=> 'cta_sub_title',
                    'type'=> 'textarea',
                    'title'=> __('CTA Subtitle','halim'),
                    'default'=> __('The Can Be Used On Larger Scale Projectss As Well As Small Scale Projects','halim'),
                    'dependency'=> array('cta_swtich','==','true')
                 ),
                 array(
                    'id'=> 'cta_btn_text',
                    'type'=> 'text',
                    'title'=> __('CTA Button Text','halim'),
                    'default'=> __('Contact Us','halim'),
                    'dependency'=> array('cta_swtich','==','true')
                 ),
                 array(
                    'id'=> 'cta_btn_url',
                    'type'=> 'url',
                    'title'=> __('CTA Button Url','halim'),
                    'default'=> 'http://www.google.com',
                    'dependency'=> array('cta_swtich','==','true')
                )
             )
         )); 

}